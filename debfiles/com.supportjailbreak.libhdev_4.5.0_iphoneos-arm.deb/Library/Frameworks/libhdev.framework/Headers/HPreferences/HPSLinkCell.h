#import <Preferences/PSSpecifier.h>
#import <Preferences/PSTableCell.h>
#import "../HUtilities/HCommon.h"
#import "HPSRootListController.h"

@interface HPSLinkCell : PSTableCell
@end
