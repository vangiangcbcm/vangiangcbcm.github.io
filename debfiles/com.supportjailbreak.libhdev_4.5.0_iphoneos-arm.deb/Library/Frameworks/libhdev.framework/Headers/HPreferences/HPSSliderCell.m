#import "HPSSliderCell.h"

@implementation HPSSliderCell
- (void)setSeparatorStyle:(UITableViewCellSeparatorStyle)style {
  [super setSeparatorStyle:UITableViewCellSeparatorStyleNone];
}
@end
