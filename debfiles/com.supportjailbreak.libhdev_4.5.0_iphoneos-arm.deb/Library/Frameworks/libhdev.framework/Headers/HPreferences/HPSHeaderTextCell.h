#import <Preferences/PSSpecifier.h>
#import "../HUtilities/HCommon.h"
#import "HPSRootListController.h"

@interface HPSHeaderTextCell : UITableViewHeaderFooterView
@end
